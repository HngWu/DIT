# topic 6

Course: Software Engineering (Software%20Engineering%206ba88675aef640088f730e287bd9affc.md)
Confidence: Not Confident
Last Edited: July 3, 2024 9:12 PM

### Product Backlog, User Stories, and Acceptance Criteria

---

### Learning Outcomes

1. **Explain the DEEP characteristics of a good Product Backlog**
2. **Write user stories using the 3Cs approach**
3. **Apply the INVEST principles in writing user stories**

---

### Product Backlog

- **Definition**: An emergent, ordered list of everything that is known to be needed for the product to achieve maximum value.
- **Responsibility**: Managed by the Product Owner, including its content, availability, and ordering.
- **Single Source**: The single source of requirements for any changes to the product.

---

![Untitled](Untitled%205.png)

### Characteristics of a Good Product Backlog

1. **Detailed Appropriately**
    - Items near the top are more detailed and smaller, ready to be worked on in the near sprint.
    - Items further down can be larger and less detailed.
2. **Emergent**
    - Continuously updated based on new information and changing needs.
3. **Estimated**
    - Each Product Backlog Item (PBI) has a size estimate to help prioritize and plan work.
4. **Prioritized**
    - Near-term items that are destined for the next few sprints are prioritized.

---

### Product Backlog Grooming (Refinement)

- **Activities**:
    - Creating and refining PBIs.
    - Estimating PBIs.
    - Prioritizing PBIs.
- **Process**: Ongoing, with the development team spending up to 10% of each sprint on refinement activities.

---

### MoSCoW Prioritization Technique

- **Must-have**: Essential for project success.
- **Should-have**: Important but not absolutely essential.
- **Could-have**: Nice to have but not essential.
- **Won't-have (this time)**: Not essential and can be excluded without jeopardizing project success.

---

### Granularity of Product Backlog Items

- **Theme**: A set of related epics with a common element.
- **Epics**: Large requirements that should be broken down into stories.
- **User Stories**: Small units of user functionality that deliver value and can be completed within a sprint.
- **Tasks**: Internal steps needed to implement a user story.

---

### What is a User Story?

- **Definition**: A short, simple description of a feature from the perspective of a user or customer.
- **Purpose**: Articulate how a piece of work will deliver value to the customer.
- **Format**: “As a [persona], I [want to], [so that].”

---

### Benefits of User Stories

- **Focus on the user**: Keeps the team centered on user needs.
- **Enable collaboration**: Encourages team and stakeholder collaboration.
- **Drive creative solutions**: Promotes innovative thinking.
- **Create momentum**: Keeps the project moving forward.

---

### INVEST Principles for User Stories

- **Independent**: Stories should be as independent as possible.
- **Negotiable**: Captures the essence of the goal and is open to discussion.
- **Valuable**: Adds value to both users and the organization.
- **Estimable**: Can be estimated for prioritization and planning.
- **Small**: Small enough to be completed within a sprint.
- **Testable**: Must be testable to be considered “done”.

---

### 3Cs Approach to Form User Stories

1. **Card**: Captures the statement of intent of the user story.
2. **Conversation**: Details behind the user stories, providing shared context.
3. **Confirmation**: Represents acceptance criteria to confirm the intended value is delivered.

---

### Acceptance Criteria

- **Definition**: Conditions that must be fulfilled for a story to be considered done.
- **Purpose**: Make it clear for testers to determine pass or fail.
- **Characteristics**:
    - State an intent, not a solution.
    - Independent of implementation.
    - High level, not every detail in writing.
- **Formats**:
    - **Given/When/Then (Gherkin syntax)**: Scenario-based, defining behavior.
    - **Verification List**: Checklist for pass/fail statements.

---

### Summary

- Different types of product backlogs and their characteristics.
- User Stories are a way to express features on the Product Backlog.
- Use the 3Cs approach to capture project requirements in user stories.
- Evaluate user stories using the INVEST principles.
- Create acceptance criteria using various formats.
# topic 8

Course: Software Engineering (Software%20Engineering%206ba88675aef640088f730e287bd9affc.md)
Confidence: Not Confident
Last Edited: July 1, 2024 7:33 PM

### Learning Outcomes

- Understand what Daily Scrum and Sprint Review are and what occurs during these events
- Describe what a Sprint Retrospective is
- Explain Velocity and Burndown Charts as progress measurement tools in Scrum

### Essence of Scrum

- 3 Roles, 3 Artifacts, 5 Events

### Scrum Events Overview

- **Purpose**: Each event is a formal opportunity to inspect and adapt.
- **Duration**: Every event has a maximum duration to ensure efficiency.

### Daily Scrum

- **Definition**: A 15-minute daily stand-up meeting for the Scrum Team.
- **Questions Addressed**:
    1. What did I do yesterday to help the team meet the Sprint goal?
    2. What will I do today to help the team meet our Sprint goals?
    3. Are there any impediments preventing the team from meeting our goals?
- **Benefits**: Optimizes team collaboration, improves communication, decision-making, and knowledge sharing.

### Sprint Review

- **Definition**: A time-boxed event held at the end of each Sprint, lasting 1 hour per Sprint week.
- **Purpose**: Demonstrates the values of openness, courage, and respect; focuses on the Sprint outcome to determine future adaptations.
- **Activities**:
    - Discussion on the current state of the product.
    - Demonstration of the Product Increment.
    - Reviewing what should be added or improved in future Sprints.
    - Items that do not meet the definition of done are returned to the Product Backlog.

### Sprint Retrospective

- **Definition**: A time-boxed event of 45 minutes per Sprint week, held after the Sprint Review.
- **Purpose**: Inspect the Sprint regarding people, processes, and tools; identify what went well and what can be improved.
- **Focus**: Increase the quality and effectiveness of the next Sprint.
- **Key Measures**:
    - Demonstrate respect and keep the team blameless.
    - Balance positive and negative feedback.
    - Act on the improvement plans.

### Burndown Chart

- **Purpose**: Visualize the state of the project, showing how much work has been done and how much remains.
- **Types**:
    - **Project/Product/Release Level**: Remaining story points after each Sprint.
    - **Sprint Level**: Remaining work in hours after each day.
- **Usage**: Scrum Master reviews regularly to ensure the team is meeting goals.

### Common Issues in Scrum

- **Late Acceptance**: Often due to an absent or remote Product Owner.
- **Slow Progress**: Causes include ambitious sprint goals, capacity changes, priority changes, and outside dependencies.
- **Early Finish**: Causes include overestimation and inclusion of buffer time.
- **Scope Increase**: Due to refinement failure or dynamic sprint backlogs.

### Velocity in Scrum

- **Definition**: The average number of points a team completes in a Sprint.
- **Purpose**: Measures the amount of work done during a Sprint; used in Sprint Planning to determine capacity.
- **Considerations**:
    - Velocity varies by team and there is no good or bad velocity.
    - Stable velocity helps in planning and stakeholder communication.

### Summary

- **SCRUM Events Covered**:
    - Daily Scrum
    - Sprint Review
    - Sprint Retrospective
- **SCRUM Tools Covered**:
    - Burndown Charts
    - Velocity
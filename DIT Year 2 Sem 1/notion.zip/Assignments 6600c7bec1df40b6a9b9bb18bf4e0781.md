# Assignments

### Due Date

[](Untitled%20de2a0501b4ad42b3857dbe12b09b5b80.csv)

### Status

[Untitled Database](Untitled%20Database%20549f651c51d94c6e92fb9a263393b739.csv)

### Completed

[Untitled Database](Untitled%20Database%20b2e5cffc8507410badd0ab41b76df645.csv)
# Practical Test 1 (20%)

Course: Full Stack Development (Full%20Stack%20Development%20277c72b877274adb9625379999580d0e.md)
Date: May 9, 2024 → May 10, 2024
Type: Exam
Status: Completed

topic 1-2
# Software Engineering

Course Code: IT2151 
Assignments: 1
Notes: topic 3 (topic%203%20438476d74f2d4421aa1dce14d1f84218.md), topic 4 (topic%204%2080c8c1692d7e4ee18d2e16eb7beb7136.md), topic 5 (topic%205%208922f0ce7f1d4ce3a344ff882213edae.md), topic 6   (topic%206%2038dc6d5278e54d0f8a0c559ab3ebfeb6.md), topic 7 (topic%207%20774ce26ab34240f395cf2b841ed1c049.md), topic 8 (topic%208%200eafc5e13abf4f83921a12d77aab005c.md), topic 11  (topic%2011%20c0600bb9cdc1459e92904b8e323e5940.md), topic 12 (topic%2012%200d60b114cdd6453aa1f646a75c6bb4d0.md), topic 13 (topic%2013%209b2e2a3a891142dc84b6cd6a84b5e3d8.md), topic 14 (topic%2014%2053ad4c8a23b447f8b993f6cdb398359d.md), topic 15 (topic%2015%203999180959b94ae3881f027dca242262.md), topic 16 (topic%2016%20c6026a7ca9c14969ba5b9336a2d9ca58.md)
Assignments/Exams: Test 1 ( 10%) Wk 3 (Test%201%20(%2010%25)%20Wk%203%20e5091987e27046d7b245c395346895c9.md), Test 2 (35%) Wk 1-2 and Wk 4-7 (Test%202%20(35%25)%20Wk%201-2%20and%20Wk%204-7%206c7717486a0b4cf1a0b8f4d0b48f4934.md), Test 3 (30%) Wk 11-13 (Test%203%20(30%25)%20Wk%2011-13%20c0bbe343b6dc452b8003e5e3d7bf2feb.md), Assignment (25%) (Assignment%20(25%25)%20f4901a10b2064f988a1655605cc72276.md)

### Assignments

[Untitled Database](Untitled%20Database%20e6cd077e338f485e9017bedfa62d98e6.csv)

### Notes

[Untitled Database](Untitled%20Database%200d1d4c0539e941478800cd1388904aa0.csv)

### Exams

[Untitled Database](Untitled%20Database%20330d211f1213415b8ca42c13b8f263c9.csv)
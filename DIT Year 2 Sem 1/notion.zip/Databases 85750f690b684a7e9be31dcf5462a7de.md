# Databases

[Courses](Courses%20c3327210c4c4422c82981911337831ca.csv)

[Notes](Notes%20e607053c33154a66a94a958ecca5f8b9.csv)

[Assignments/Exams](Assignments%20Exams%20f7fad93d5a284269bc84c70e435bae8a.csv)
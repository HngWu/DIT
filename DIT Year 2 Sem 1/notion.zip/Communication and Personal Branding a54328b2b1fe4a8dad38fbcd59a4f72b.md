# Communication and Personal Branding

Course Code: ITF212
Assignments: 1
Assignments/Exams: ICA #1 (ICA%20#1%2079107e09224f42958335b526bce6f5d5.md), ICA #2 (ICA%20#2%209d1bc9767ea04a9b90a8af499f731d1a.md), ICA #3 (ICA%20#3%20d68dce94c66747c698075ed70a27a307.md)

### Assignments

[Untitled Database](Untitled%20Database%20719dfb60a43d4850b8c325f3c6dfd0c3.csv)

### Notes

[Untitled Database](Untitled%20Database%209fffda127c8443bf97a04fe9ae443119.csv)

### Exams

[Untitled Database](Untitled%20Database%20513c7435b777479592e4b76fe998d9af.csv)
# 2. Kinematics

Confidence: Not Confident
Last Edited: April 6, 2024 5:20 PM

- Kinematics is the branch of physics that deals with the motion of objects without considering the forces causing the motion.
- It focuses on describing the motion of objects in terms of displacement, velocity, and acceleration.
- Displacement is a vector quantity that represents the change in position of an object in a specific direction.
- Velocity is the rate of change of displacement with respect to time and includes both magnitude and direction.
- Acceleration is the rate of change of velocity with respect to time and also includes both magnitude and direction.
- The three fundamental equations of motion, known as the SUVAT equations, relate displacement, initial velocity, final velocity, acceleration, and time.
- The equations are:
    - v = u + at (final velocity = initial velocity + acceleration × time)
    - s = ut + 0.5at² (displacement = initial velocity × time + 0.5 × acceleration × time²)
    - v² = u² + 2as (final velocity² = initial velocity² + 2 × acceleration × displacement)
- Graphical representations, such as position-time graphs and velocity-time graphs, are used to analyze and interpret motion.
- In addition to linear motion, kinematics also includes the study of projectile motion and motion in two dimensions.
- Projectile motion involves the motion of objects launched into the air under the influence of gravity, and it can be analyzed using concepts of horizontal and vertical motion.
- Motion in two dimensions refers to the simultaneous motion of objects in both the x-axis and y-axis directions, often represented by vectors.
- Kinematics provides a foundation for further study of dynamics, which involves the forces and causes of motion, and other areas of physics such as mechanics, astrophysics, and engineering.
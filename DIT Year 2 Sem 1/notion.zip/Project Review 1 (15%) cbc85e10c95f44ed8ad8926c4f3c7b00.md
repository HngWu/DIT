# Project Review 1 (15%)

Course: Full Stack Development (Full%20Stack%20Development%20277c72b877274adb9625379999580d0e.md)
Date: June 28, 2024
Type: Assignment
Status: Not Started
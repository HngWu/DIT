# Fundamentals of Computer Systems

Confidence: Not Confident
Last Edited: April 6, 2024 5:20 PM

- A computer system consists of hardware and software components that work together to perform various tasks.
- The central processing unit (CPU) is the brain of the computer, responsible for executing instructions and performing calculations.
- Memory, such as random access memory (RAM), stores data and instructions that are currently being used by the CPU.
- Secondary storage devices, like hard drives or solid-state drives, provide long-term storage for programs and data.
- Input devices, such as keyboards and mice, allow users to provide instructions and data to the computer.
- Output devices, including monitors and printers, display or produce the results or information processed by the computer.
- The operating system (OS) is a software that manages computer resources and provides an interface for users to interact with the computer.
- The OS handles tasks such as memory management, file system management, process scheduling, and device control.
- Data representation is the way in which information is encoded and stored in a computer system.
- Binary, a base-2 number system, is used to represent data in computers using only 0s and 1s.
- Hexadecimal, a base-16 number system, is often used to represent binary numbers more compactly.
- ASCII (American Standard Code for Information Interchange) is a character encoding standard that assigns numeric codes to represent characters.
- Computer networks connect multiple computers and devices to enable communication and data sharing.
- Local Area Networks (LANs) cover a small geographical area, while Wide Area Networks (WANs) span larger distances.
- Network protocols, such as TCP/IP, govern how data is transmitted and received across networks.
- Communication technologies like Ethernet, Wi-Fi, and cellular networks provide the means for devices to connect and communicate.
- Network security is important to protect data and systems from unauthorized access, and it involves measures like firewalls, encryption, and user authentication.
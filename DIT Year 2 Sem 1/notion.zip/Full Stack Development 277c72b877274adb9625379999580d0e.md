# Full Stack Development

Course Code: IT2155
Assignments: 0.5
Assignments/Exams: Practical Test 1 (20%) (Practical%20Test%201%20(20%25)%2090fd7ab0b19e4dbea62063a0ef67e17e.md), Proposal Presentation (20%) (Proposal%20Presentation%20(20%25)%20e0d366918a454370a7926e880fd71e41.md), Project Review 1 (15%) (Project%20Review%201%20(15%25)%20cbc85e10c95f44ed8ad8926c4f3c7b00.md), Project Review 2 (15%) (Project%20Review%202%20(15%25)%2086218c20b3aa4ddc88105a7bb646e7c5.md), Final Presentation (30%) (Final%20Presentation%20(30%25)%20f96b7f4f81654f2a97dd2761cad4f3c9.md)

### Assignments

[Untitled Database](Untitled%20Database%20e4942a7d0882418f9dfa81174945eaa6.csv)

### Notes

[Untitled Database](Untitled%20Database%20e5470743073a4ef3922a2592fbe7c0f4.csv)

### Exams

[Untitled Database](Untitled%20Database%20d16edf90d240437c8e241ca464bb18de.csv)
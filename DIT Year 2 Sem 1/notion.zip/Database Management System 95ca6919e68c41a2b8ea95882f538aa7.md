# Database Management System

Course Code: IT2152
Assignments: 1
Notes: Topic 1 (Topic%201%20380e52cc2cc24c18a7232c9fa8219821.md), Topic 2 (Topic%202%20aaa6b8a264174575bb5b644a61368e8d.md), Topic 3 (Topic%203%204a88e733b38c4553b9623aafefe0bdb3.md), Topic 11-13 (Topic%2011-13%203059daf1b1424763a228f383cc20b1c9.md)
Assignments/Exams: Assignment 1 (20%), due Sun 23:59 (12 May 2024) (Assignment%201%20(20%25),%20due%20Sun%2023%2059%20(12%20May%202024)%20e80cb31215cc4977949e0ab5a1969635.md), Test 1 (30%) wk 1-6 (Test%201%20(30%25)%20wk%201-6%20d217b244f56e4d32ac4d96f25b76f745.md), Test 2 (30%) wk 11-13 (Test%202%20(30%25)%20wk%2011-13%2090d37da91aec4abc9fc149098bf599e5.md), Assignment 2 (20%), due Sun 23:59 (4 Aug 2024) (Assignment%202%20(20%25),%20due%20Sun%2023%2059%20(4%20Aug%202024)%207c9799f9352c4f72966fce5b2093007c.md)

### Assignments

[Untitled Database](Untitled%20Database%208eb4e16b99e84873897ec45c494e98d2.csv)

### Notes

[Untitled Database](Untitled%20Database%20975f76f186dd4dd8ad0106c787a4544b.csv)

### Exams

[Untitled Database](Untitled%20Database%200ffa4eeb80d34585be09e0a4ac452760.csv)
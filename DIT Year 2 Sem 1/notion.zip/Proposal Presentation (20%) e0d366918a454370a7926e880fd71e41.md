# Proposal Presentation (20%)

Course: Full Stack Development (Full%20Stack%20Development%20277c72b877274adb9625379999580d0e.md)
Date: May 23, 2024 → May 24, 2024
Type: Assignment
Status: Completed
# Data Representation and Manipulation

Confidence: Not Confident
Last Edited: April 6, 2024 5:20 PM

- Data representation is the process of encoding and storing information in a format that can be understood and processed by a computer system.
- Binary is the base-2 number system used by computers, representing data using only two digits: 0 and 1.
- Each binary digit is called a bit, and a group of 8 bits is called a byte.
- Hexadecimal is a base-16 number system often used in computing to represent binary numbers more compactly. It uses digits from 0 to 9 and letters from A to F to represent values from 0 to 15.
- Data types determine the kind of data that can be stored and manipulated in a programming language. Examples include integers, floating-point numbers, characters, and strings.
- Bitwise operations allow manipulation of individual bits within a binary representation. These operations include AND, OR, XOR, and bit shifting.
- Numeric data can be represented in different formats, such as signed or unsigned integers, fixed-point, or floating-point numbers.
- Two's complement is a method of representing signed integers in binary, where the leftmost bit represents the sign (0 for positive, 1 for negative).
- Characters are represented using character encoding schemes such as ASCII (American Standard Code for Information Interchange) or Unicode.
- Data structures provide a way to organize and store collections of related data. Examples include arrays, lists, stacks, and queues.
- Arrays are fixed-size data structures that store elements of the same type, accessed by their index. They provide efficient random access to elements.
- Records or structures allow grouping related data items into a single entity, often with different data types for each field.
- Linked lists are dynamic data structures consisting of nodes, each containing data and a reference to the next node.
- File organization refers to the structure and layout of data within a file. Sequential and random access methods are commonly used for reading and writing data.
- Compression techniques are used to reduce the size of data, enabling more efficient storage and transmission. Examples include lossless compression (e.g., ZIP) and lossy compression (e.g., JPEG).
- Data validation ensures the correctness and integrity of data, including checks for data type, range, and consistency.
- Data manipulation involves operations on data, such as sorting, searching, filtering, and transforming data using algorithms and programming techniques.
# Data Structures and Algorithms

Course Code: IT2153
Assignments: 1
Notes: Test 1 (Test%201%205c7382026fdb425a88476593a57e25f5.md)
Assignments/Exams:  TEST1(proc)= 20% (wk5) (TEST1(proc)=%2020%25%20(wk5)%20c5550385ff3b440790536f75771e92c6.md), ASSN1=20% (wk8) (ASSN1=20%25%20(wk8)%205c7834409eaa49ec844ff916cb78b0d4.md), TEST2(proc)= 30% (wk13) (TEST2(proc)=%2030%25%20(wk13)%20f8f6ff85dec744c58b5d32df988cf02f.md), ASSN2=30% (wk17) (ASSN2=30%25%20(wk17)%204c8c1034eb244055b6959db80cc60cc7.md)

### Assignments

[Untitled Database](Untitled%20Database%20e435adbef1bb49489bd7637d88616529.csv)

### Notes

[Untitled Database](Untitled%20Database%2089abe6c9bf8a41a2abf9fb7a276be18f.csv)

### Exams

[Untitled Database](Untitled%20Database%20b999f1c5f2ad4e55a70643bc12047616.csv)
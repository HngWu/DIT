# Assignment 1(30%)

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Date: November 18, 2024
Type: Assignment
Status: Completed

Part 1:

```powershell
Net user SIT /passwordreq:yes
Net user SIT

```

![image.png](Assignment%201(30%25)%20118b65ee4ea6804d979cc3ed089e4dcc/image.png)

```powershell
# 1. Guest Account Check and Disable
Get-LocalUser -Name "Guest" | Disable-LocalUser

# 2. Check and Remove Unnecessary Accounts
# List all user accounts
Get-LocalUser | Select-Object Name, Enabled, LastLogon

# 3. Password Protection Check
Get-LocalUser | Where-Object {$_.PasswordRequired -eq $false} | Set-LocalUser -PasswordRequired $true

# 4. Set Strong Password Policy
# Run in elevated PowerShell
secedit /export /cfg c:\secpol.cfg
(Get-Content C:\secpol.cfg) | ForEach-Object {
    $_ -replace "PasswordComplexity = 0", "PasswordComplexity = 1" `
       -replace "MinimumPasswordLength = \d+", "MinimumPasswordLength = 12" `
       -replace "PasswordHistorySize = \d+", "PasswordHistorySize = 5"
} | Set-Content C:\secpol.cfg
secedit /configure /db c:\windows\security\local.sdb /cfg c:\secpol.cfg /areas SECURITYPOLICY
Remove-Item C:\secpol.cfg -Force

# 5. Set Account Lockout Policy
net accounts /lockoutthreshold:5 /lockoutduration:30 /lockoutwindow:30

# 6. Disable Internet Connection Sharing
Set-Service -Name SharedAccess -StartupType Disabled
Stop-Service -Name SharedAccess

# 7. Enable Protected File Sharing
# Enable network sharing encryption
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RequireSecuritySignature" -Value 1

# 8. Enable Windows Firewall
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True

# 9. Disable Unnecessary Services
$unnecessaryServices = @(
    "XboxGipSvc",
    "XblAuthManager",
    "XblGameSave",
    "XboxNetApiSvc"
)

foreach ($service in $unnecessaryServices) {
    Set-Service -Name $service -StartupType Disabled
    Stop-Service -Name $service -Force
}

# 10. Software Restriction Policies
# Create basic executable restrictions
$path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers"
New-Item -Path $path -Force
Set-ItemProperty -Path $path -Name "DefaultLevel" -Value 262144

# 11. Windows Defender Settings
Set-MpPreference -DisableRealtimeMonitoring $false
Set-MpPreference -DisableIOAVProtection $false

# 12. Windows Update Settings
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name "AUOptions" -Value 4
```

Part 2:

```powershell
# 1. Create Restricted User Account for Tom
New-LocalUser -Name "Tom" -Description "Temporary Wordpad User" -Password (ConvertTo-SecureString "ComplexPass123!" -AsPlainText -Force)
Add-LocalGroupMember -Group "Users" -Member "Tom"

# 2. Configure Disk Quota for Tom
# Enable quota management
Enable-WindowsOptionalFeature -Online -FeatureName "FileAndStorage-Services"
fsutil quota enforce C:
# Set quota for Tom's folder
fsutil quota modify C: 52428800 41943040 "Tom"

# 3. Create Software Restriction Policy
$wordpadPath = "$env:ProgramFiles\Windows NT\Accessories\wordpad.exe"
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers\262144\Paths" -Force
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers\262144\Paths\$wordpadPath" -Name "ItemData" -Value 0
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers\262144\Paths\$wordpadPath" -Name "SaferFlags" -Value 0

# 4. Block Internet Access for Tom
New-NetFirewallRule -DisplayName "Block Tom Internet" -Direction Outbound -Action Block -Profile Any -UserAccount "Tom"

# 5. Disable USB Storage for Tom
$usbPolicy = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices"
New-Item -Path $usbPolicy -Force
Set-ItemProperty -Path $usbPolicy -Name "Deny_All" -Value 1
```
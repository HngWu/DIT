# Assignment 3 (35%)

Course: UX Design Methods & Techniques (../Courses%20116b65ee4ea6813db5b5d6925de4320b/UX%20Design%20Methods%20&%20Techniques%20116b65ee4ea68012b579e8b1798b2f66.md)
Date: February 3, 2025
Type: Assignment
Status: Not Started

Plan:

- Figma prototype
    - check all hyperlinks
    - touch up pages
    - link ≥ 15 design principles to the prototype
    - link psychology of interaction design to pages
    - check all colors, fonts, buttons
- Usability test plan:
    - create google forms for overall test
    - Reword entire document
    
    - double check and refine test task
    - include all the details to complete the task
    - 
- usability evaluation report:
    - (To be discussed)
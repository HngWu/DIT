# Assignment 2 (35%)

Course: UX Design Methods & Techniques (../Courses%20116b65ee4ea6813db5b5d6925de4320b/UX%20Design%20Methods%20&%20Techniques%20116b65ee4ea68012b579e8b1798b2f66.md)
Date: November 25, 2024
Type: Assignment
Status: Completed
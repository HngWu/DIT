# Notes For Test 1

Course: Market Research and Technology Trends (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Market%20Research%20and%20Technology%20Trends%20116b65ee4ea680daa2cdc3ceaf468f24.md)
Confidence: Not Confident
Last Edited: December 12, 2024 1:07 PM

# Topic 1: Market Research Fundamentals

## What is Market Research?

Market research is the process of collecting opinions about new services or products directly from potential customers. It helps companies understand their target market and gather feedback about product/service interest.

## Importance of Market Research

- Verify market need
- Identify competitors
- Improve company offerings
- Satisfy customers

## Types of Market Research

### 1. Primary Data Research

Primary research involves collecting new data specifically for the problem at hand:

- Usually uses questionnaires
- More expensive and time-consuming
- Provides conclusive, targeted results

### 2. Secondary Data Research

Secondary research uses existing compiled data:

- Includes reports from government agencies, trade associations, and businesses
- More affordable and faster to obtain
- Commonly used by small businesses with limited budgets

# Technology Trends and Digital Landscape

## Key Focus Areas

- IMDA Technology Roadmap - Singapore's digital technology hub initiatives
- Service 4.0 - Next generation of service delivery
- Emerging Trends (Gartner) - Critical business technology trends
- Technology Leaders' Products - Industry insights and applications
- Robotics Process Automation (RPA) - Implementation and use cases

## Digital Economy Impact

The digital economy operates on the principle of "disrupt or be disrupted." IT professionals must maintain foresight about relevant technology landscapes for career development.

## Importance of Lifelong Learning

Constant technological changes require continuous skill development. Identifying and acquiring the right skillsets is crucial for building future value in the IT industry.

## Topic 2: Market Research Methods

### Qualitative Research

- **Focus Groups:** Group discussions to gather opinions and reactions to products/services
- **User Interviews:** One-on-one conversations to understand individual experiences and needs
- **Ethnography:** Observing customers in their natural environment
- **Diary Studies:** Participants record their experiences and behaviors over time

### Quantitative Research

- **Surveys:** Structured questionnaires to collect numerical data from large samples
- **Data Analytics:** Analysis of web traffic, user behavior, and other measurable metrics
- **Eye Tracking:** Measuring visual attention and engagement

Both qualitative and quantitative methods are valuable and often used together for comprehensive insights.

### Research Presentation Tools

- **Personas:** Fictional characters representing different user segments
- **Journey Maps:** Visual representations of customer experiences across touchpoints
- **Data Visualizations:** Charts and graphs to communicate findings effectively

# Topic 3: IMDA and Singapore's Digital Transformation

## About IMDA

The Infocomm Media Development Authority (IMDA) is a statutory board in Singapore that develops and regulates the infocomm and media sectors.

## Singapore Digital (SG:Digital) Movement

SG:Digital is a nationwide initiative to unify Singapore's digitalisation efforts, targeting three main groups:

1. Companies - Provides programs to help SMEs digitalize
2. Talent - Focuses on building digital capabilities through programs like:
    - TechSkills Accelerator (TeSA)
    - Media Manpower Programme
    1. Pervasive Adoption of AI - Focuses on AI products & services, process, and insight applications
    - Skills Framework
    - SG:Digital Scholarship
3. Communities - Ensures technology remains inclusive and accessible to all

## 9 Key Technology Trends

1. Pervasive adoption of AI
2. Empathetic, Cognitive and Affective AI - Development of emotional intelligence in AI systems
3. Greater Human-Machine Collaborations - Including humanoid robots and cobots
4. Natural Technology Interfaces - Combining AR, VR, and IoT through Mixed Reality
5. Codeless Development Tools - Democratization of technology creation
6. Digital Platforms and As-a-service Architectures
7. Hybrid and Multi-Cloud Deployment
8. Blockchain for Trust - Enabling transparent and secure transactions
9. API Economy - Facilitating system communication and asset reuse
    - Easy Communication between Systems Incorrectly unchecked
    - Reusable across and beyond the enterprise Correctly checked
    - Ignite creative new ways for business to use existing data, transactions and products

These trends are shaping Singapore's digital economy and driving the transition towards Services 4.0.

# Topic 4: Services 4.0 Evolution

## Historical Development

### Services 1.0

Characterized by manual services with basic tool assistance (e.g., electronic typewriters for bookkeeping).

### Services 2.0

Marked by efficient, internet-enabled services that improved service delivery.

### Services 3.0

Introduced self-service capabilities enabled by mobile, wireless, and cloud technologies.

### Services 4.0

- Services 4.0 is a modern service concept that leverages technologies to meet changing customer needs, and to deliver higher quality experiences.
- **Frictionless, anticipatory, empathic and end-to-end.**
- Using various technologies, it aims to automate repetitive, mundane tasks, freeing humans to focus on other more valuable roles. At the same time, it augments workers’ capabilities, empowering them to be more creative, analytical, innovative and emotionally intelligent.
- Represents the next evolution featuring seamless, end-to-end, frictionless services that can anticipate customer needs using emerging technologies.(not important)

To support Services 4.0, the Infocomm and Media (ICM) ecosystem will need to respond collectively to deliver solutions that are as follows: 

- more cost effective
- scalable according to demand
- provide easier access to emerging technologies
- support the changing needs of service providers in an agile manner

## Key Features of Services 4.0

- Seamless end-to-end service delivery
- Anticipatory customer needs fulfillment
- Integration of emerging technologies
- Human-centric service approach
- Automation of repetitive tasks

## Objectives and Stakeholders

### 5 Key Objectives

1. Seamless experience
    1. meet changing customer needs
2. Value 
    1. create new value and achieve high productivity
3. New jobs
    1. create and enhance jobs
4. Accessible technology
    1. make emerging technologies more accessible
5. Inclusivity
    1. create inclusive ecosystems for companies
    2. achievable

### 3 Main Stakeholders

1. Users and Consumers of services
2. Service Providers
3. ICM solution providers

## Implementation Examples

- DBS Call Centre Evolution
    
    - Implemented call predictions for better customer service
    - Developed 'Zero Contact Resolution' system
    - Integrated analytics and chatbots for digital solutions
    
- IRAS Digital Transformation
    
    - Launched LEA:D movement (Analytics, Design, Digitalisation)
    - Created API marketplace for developer collaboration
    - Enhanced digital services with User Experience Design
    
- Singtel's Digital Workforce
    
    - Deployed RPA for automation
    - Developed ATOM bot
    - Created AI-powered chatbot Shirley for customer service
    

# Topic 4: Janio Case Study

## Company Background

Founded in Singapore in 2018, Janio was created to address the gap in Southeast Asian logistics solutions. The company aims to build Asia's leading logistics network through integrated cross-border delivery solutions.

## Business Model

- Operates as a technology platform
- Serves e-commerce marketplaces, business owners, and logistics partners
- Connects key players across Southeast Asia's e-commerce ecosystem
- Goal: Create an integrated network to simplify Asia's supply chain on a single platform

## Cloud Services Implementation

### Key Benefits

1. **Ease of Use:** Cloud-based web services simplified setup and reduced setup time
2. **Rapid Development:** Cloud development tools enabled auto-deployment without operational disruption
3. **Scalability:** Cloud resources could be easily adjusted based on order and query loads

### Technology Stack

- Google Cloud
- AWS (Amazon Web Services)
- Heroku
- Semaphore

These cloud services supported Janio's operational pipeline and provided competitive advantages. According to CMO Nathaniel Yim, this infrastructure enabled Janio to launch within three months and scale from handling tens of orders to thousands per day.

# Topic 5: Gartner Technology Trends

## About Gartner

Gartner, Inc. is a leading technological research and consulting firm based in Stamford, Connecticut. They conduct extensive research on technology and share insights through consulting, executive programs, and conferences.

## Strategic Technology Trends

Gartner identifies critical technology trends annually to help CEOs deliver growth, digitalization, and efficiency. These trends position CIOs and IT executives as strategic partners in organizations.

### Key Trends Overview

1. Data Fabric - Architecture that enables end-to-end data integration across platforms
2. Cybersecurity Mesh - Composable security approach based on identity verification
3. Privacy-Enhancing Computation - Enables data sharing while preserving privacy
4. Cloud-Native Platforms - Leverages core cloud computing capabilities for faster value delivery
5. Composable Applications - Uses packaged-business capabilities for rapid application development
6. Decision Intelligence - Framework for improved organizational decision-making
7. Hyperautomation - Business-driven approach to automate processes using multiple technologies
8. AI Engineering - Discipline for operationalizing AI models effectively with strong governance 
9. Distributed Enterprises - Virtual-first approach to digitize consumer touchpoints
10. Total Experience - Unifies customer, user, employee, and multiexperience
11. Autonomic Systems - Self-managing systems that learn from their environments
12. Generative AI - AI that creates new, original content based on training data

### Key Statistics and Predictions

- By 2024, data fabric deployments will quadruple efficiency in data utilization
- By 2024, cybersecurity mesh architecture will reduce security incident impacts by 90%
- By 2025, 60% of large organizations will use privacy-enhancing computation techniques
- By 2024, composable applications will be the primary design approach for new systems
- By 2025, generative AI will account for 10% of all data produced, up from less than 1% today

## Gartner's 2025 Strategic Technology Trends

### Three Main Categories

1. **AI Imperatives and Risks**
    - Agentic AI - Software programs making autonomous decisions
    - AI Governance Platforms - Manage and control AI systems ethically
    - Disinformation Security
2. **Human-Machine Synergy**
    - Spatial Computing
    - Polyfunctional Robots
    - Neurological Enhancement
3. **New Frontiers of Computing**
    - Post-Quantum Cryptography
    - Ambient Invisible Intelligence
    - Energy-Efficient Computing
    - Hybrid Computing

### Key Predictions

- By 2028, at least 15% of day-to-day work decisions will be made autonomously through agentic AI
- Organizations using AI governance platforms will achieve 30% higher customer trust ratings and 25% better regulatory compliance scores by 2028

These trends are selected based on their potential to disrupt traditional business models, enable innovation, and address pressing enterprise challenges.

# Osome - Services 4.0 Case Study

## Company Overview

Osome is a Singapore-based company providing online incorporation, secretarial, and accounting services, serving over 600 customers as of January 2018.

## Key Services 4.0 Features

- AI-human hybrid service delivery model
- 38-minute company incorporation process
- 24/7 online service availability with 15-minute response time
- Paperless, electronic processing system
- Multi-platform accessibility (desktop and mobile)

## Technical Infrastructure

- Cloud-native applications built on Amazon AWS
- Integration with external APIs (Google, IBM, Xero)
- Advanced technologies including AI and OCR
- Connected to government services (ACRA, MOM) through APIs

## Success Factors

1. Strong front-end user experience and product design
2. Robust back-end architecture
3. Focus on customer needs anticipation
4. Skilled agents providing personalized service
5. Strong ecosystem of Services 4.0 partners
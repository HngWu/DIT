# Topic 11 (not tested)

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: January 27, 2025 1:42 PM

# **Notes on OS Design (Chapter 11 - Operating Systems and Administration)**

---

## **Objectives**

- Understand **design considerations** for an operating system (OS).
- Learn the **characteristics of monolithic kernels**.
- Understand the **object-oriented OS design** approach.
- Learn the design of **Linux** and **Windows NT** kernels.

---

## **Design Considerations**

Designing an OS involves multiple considerations due to its complexity and the interaction between software and hardware.

### **Key Considerations**:

1. **Performance**:
    - OS activity is considered **overhead**, and performance remains a **top priority**.
    - Modern hardware improvements reduce bottlenecks but do not eliminate the need for efficiency.
    - Fast code is generally achieved using structured programming languages like **C**, rather than **OO languages** like C++.
2. **Trusted Software**:
    - OS kernels must ensure **trustworthiness**:
        - Sensitive operations are performed in **supervisor mode**.
        - Misbehaving programs are halted to prevent system damage.
3. **Modularization**:
    - OS is divided into **independent software modules**.
    - Benefits:
        - Simplifies updates and customization.
        - Allows adding/modifying hardware interfaces (e.g., Linux drivers) without recompiling the entire kernel.
4. **Portability**:
    - Ability to **run on different hardware platforms**.
    - Achieved through **hardware abstraction layers (HAL)**:
        - Low-level software modules handle hardware-specific functions.
        - Example:
            - **Windows HAL** abstracts hardware dependencies.
            - **Linux kernel modules** enable similar abstraction.

---

## **OS Design Paradigms**

### **Monolithic Kernels**

- Examples: **Windows**, **UNIX**.
- Characteristics:
    - All OS components and data structures are in **one logical module**.
    - **Efficient performance** due to direct access between components.
    - **Challenges**: Difficult to maintain and understand due to lack of separation between components.

### **MS-DOS (Monolithic Kernel Example)**

- Kernel implemented in:
    - Read-only **BIOS routines**.
    - Two executable files: `IO.SYS` and `MSDOS.SYS`.
- Extensions via configuration files (`CONFIG.SYS`, `AUTOEXEC.BAT`) for drivers and additional hardware support.

### **UNIX (Monolithic Kernel Example)**

- Developed by AT&T researchers.
- Design:
    - A single logical module handling:
        - **Process and resource management**.
        - **Memory management**.
        - **File management**.

---

### **Object-Oriented OS**

- A **modular kernel** design.
- **Key Features**:
    - Partitioned into **logically independent components**.
    - Components interact through **well-defined interfaces**.
    - **Advantages**:
        - Easier to maintain and modify due to clear boundaries.
    - **Disadvantages**:
        - Use of interfaces leads to inefficiencies.
    - **Status**:
        - No commercial implementations yet.

---

### **Extensible Kernels**

- Modular and customizable.
- Examples: **Windows NT extensibility via HAL**, **Linux kernel modules**.

---

## **Linux Kernel**

- Based on UNIX design (**monolithic kernel**).
- Supports **modules**:
    - Mechanism to add or remove code (e.g., device drivers) dynamically.

### **Linux Kernel Organization**:

- Layers include:
    1. **Linux Kernel**: Core of the OS.
    2. **Modules**: Dynamic components for functionality (e.g., device drivers).
    3. **Module Interface**: Facilitates interaction between modules and the kernel.

---

## **Windows Kernel**

- **Monolithic kernel** design.
- **Key Features**:
    - Provides objects and threads that interface with the **HAL** and hardware layers.
    - Windows **NT Executive** builds on the kernel to manage policies and services.

### **Components of Windows Kernel**:

1. **Object Manager**: Manages kernel objects.
2. **Process & Thread Manager**: Handles process creation and scheduling.
3. **Virtual Memory Manager**: Manages memory allocation and paging.
4. **I/O Manager**: Handles input/output operations.
5. **Cache Manager**: Improves performance by caching frequently used data.

---

### **Windows NT/2000 Architecture**:

- **Key Layers**:
    1. **Subsystems**:
        - User and Supervisor subsystems manage high-level tasks.
    2. **NT Executive**:
        - Manages OS policies and services.
    3. **NT Kernel**:
        - Provides core OS functionality.
    4. **HAL** (Hardware Abstraction Layer):
        - Abstracts hardware-specific details.

---

## **OS Software Organization**

Operating systems can be designed using different software architectures:

1. **Monolithic**:
    - All components in one module.
    - Example: UNIX, MS-DOS.
2. **Modular**:
    - Independent modules allow for easier updates and maintenance.
    - Example: Linux kernel modules.
3. **Extensible**:
    - Modular but customizable for different hardware platforms.
    - Example: Windows NT.
4. **Layered**:
    - Each layer performs specific functions and interacts only with adjacent layers.
    - Simplifies debugging and maintenance.

---

## **Conclusion**

- Modern OS designs have evolved over decades to balance **performance**, **modularity**, **portability**, and **trustworthiness**.
- **Monolithic kernels** dominate commercial OS designs (e.g., Linux, Windows) due to performance benefits.
- Ongoing research explores **object-oriented** and other innovative designs to further improve OS efficiency and maintainability.
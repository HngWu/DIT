# Topic 10

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: February 10, 2025 1:58 PM

# **Notes on File Management (Chapter 10 - Operating Systems and Administration)**

---

## **Objectives**

- **Understand the structure** of low-level files.
- Learn the design of **high-level file abstraction**.
- Understand **three disk allocation methods**.
- Know the structure of a **typical file system**.

---

## **The Need for Files**

- Computers require **non-volatile storage** for data.
    - Example: Storing company data, application programs, etc.
- **Files** are the OS mechanism for organizing and managing data for storage.
- Types of files:
    - **Executable** files, **data** files, **text** files (e.g., HTML), among others.

---

## **Files and File Manager**

- Most applications require reading from or writing to files.
- **Programming languages** provide file-handling routines that invoke **OS system calls** for file operations.
- **File Manager** (part of the OS):
    - Responsible for handling and managing file operations (open, read, write, close).

---

## **Low-Level Files**

- In **low-level file handling**, data is stored in **blocks** on storage devices.
- OS system calls for low-level file handling:
    - `open()`, `read()`, `write()`, `close()`, `seek()`.
- Blocks on storage devices are managed as a stream of bits.

---

## **Block Management**

- **Blocks** are the basic units of storage, usually of equal size.
- **Three techniques** for organizing data blocks:
    1. **Contiguous Allocation**
    2. **Linked Allocation**
    3. **Indexed Allocation**

---

### **1. Contiguous Allocation**

- Files occupy a **contiguous set of blocks** on the disk.
- Each file is defined by:
    - **Starting block address**.
    - **Length** (in block units).
- Example:
    - File `f` occupies 2 blocks, and `mail` occupies 6 blocks.

### **Advantages**:

- Supports **sequential** and **direct access**.
    - Sequential: Minimal disk seek time.
    - Direct: Access block `i` of a file at `b + i`.
- Minimal **disk seek time** (blocks are adjacent).
- easy to implement

### **Disadvantages**:

1. **External Fragmentation**:
    - Free disk space gets fragmented into small, non-contiguous blocks.
    - Solution: **Compaction** to consolidate free space (time-intensive).
2. **Unknown File Size**:
    - Difficult to allocate space for files with unknown or growing size.

---

### **2. Linked Allocation**

- Files are stored as a **linked list of blocks**:
    - Blocks can be located anywhere on the disk.
    - Each block contains a **pointer** to the next block.
- Directory contains pointers to the **first** and **last blocks** of a file.
- Example:
    - A file might link blocks 9 → 16 → 1 → 10 → 25.

### **Advantages**:

1. No **external fragmentation**.
    - Any free block can be used.
2. No need to declare the file size in advance.

### **Disadvantages**:

1. **Inefficient for direct access**:
    - Must traverse the linked list to find block `i`.
2. **Pointer space overhead**:
    - Each block uses extra space to store pointers.
3. **Reliability issues**:
    - If a pointer is corrupted, the file's structure is compromised.

---

### **3. Indexed Allocation**

- Solves the **direct access problem** of linked allocation.
- Each file has an **index block** containing pointers to all its blocks.
    - Example: The `i-th` entry in the index block points to the `i-th` block of the file.
- Directory contains the **address of the index block**.

### **Advantages**:

1. Supports **direct access**.
2. No **external fragmentation**.

### **Disadvantages**:

1. **Wasted space**:
    - Index block overhead is greater than linked allocation.
    - Unused index entries waste space.
2. **Index block size**:
    - If too small: Not enough pointers for large files.
    - If too large: Wasted space.

---

## **File Allocation Table (FAT)**

- **Variation of linked allocation**, used in **MS-DOS/Windows**.
- FAT stores the **block pointers** for all files in a table at the beginning of the disk.
- **Process**:
    - Directory entry contains the first block number.
    - FAT entry for each block points to the next block in the file.
- **Limitations**:
    - High **disk head seek** unless FAT is cached.
    - File system size is limited (improved in FAT32).

---

## **UNIX File Structure**

- UNIX/Linux uses a **variant of indexed allocation** with **indirect indices** for managing large files:
    - **Direct blocks**: Point directly to data blocks.
    - **Single indirect blocks**: Point to an array of data block pointers.
    - **Double/Triple indirect blocks**: Provide multiple levels of indexing for very large files.
- UNIX file descriptors (`inodes`) store metadata like:
    - Mode, owner, size, timestamps, pointers to blocks.

---

## **File Descriptors**

- **File descriptors** are metadata maintained by the file manager to describe files.
- Includes:
    - **External name**, current state, sharable , **owner**, user, **locks**, **protection settings, length**.
    - Timestamps: Time of **Creation**, Time of **last modification**, Time of **last access**.
    - **Storage device details**, reference count

---

## **Directories**

- **File directories** manage and organize collections of files.
- Provide mechanisms to:
    - **Enumerate**: List files (`dir`, `ls`).
    - **Copy**: Duplicate files (`cp`).
    - **Rename**: Change file name (`mv`).
    - **Delete**: Remove files/directories (`rm`).
    - **Traverse**: Navigate directories (`cd`, `pwd`).

### **Directory Structures**

1. **Flat Namespace**:
    - All files stored in a single directory.
    - Inefficient for large numbers of files.
2. **Hierarchical Namespace**:
    - Files and directories are organized in a tree structure.
    - Allows nesting of directories and files.
    - Common in modern OS (e.g., Linux, Windows).

---

### **Hierarchical Directories in Linux**

- Standard sub-directories:
    
    
    | **Directory** | **Description** |
    | --- | --- |
    | `/bin` | User programs (e.g., `ls`). |
    | `/sbin` | System programs (e.g., `clock`). |
    | `/lib` | Shared libraries for `/bin` and `/sbin`. |
    | `/dev` | Device files. |
    | `/boot` | Kernel and bootloader programs. |
    | `/etc` | Configuration files. |
    | `/proc` | Virtual files for system state. |
    | `/mnt` | Temporarily mounted filesystems. |
    | `/usr` | Programs for all users. |
    | `/var` | Logs and variable data. |
    | `/home` | User account directories. |
    | `/tmp` | Temporary files. |
    | `/root` | Home directory for the root user. |
    | `/opt` | Third-party software packages |

---

## **Conclusion**

- **File systems** enable stable and organized storage of data in computer systems.
- **File managers** provide:
    - File and directory management mechanisms.
    - Interfaces for applications to manage data.
- **Different allocation methods** and **directory structures** affect performance and efficiency.
- Hierarchical directories and advanced file management techniques improve file organization and usability.
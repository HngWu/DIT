# Practical 6

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: February 9, 2025 9:28 AM

# **IT2164/IT2561: Operating Systems and Administration**

## **Practical 6: Linux Administration – Shell Commands**

### **Pre-Requisites & Objectives**

- **Getting Started**
- **Linux Shell**
- **Changing Your Password**
- **Knowing Who is Logged In**
- **Current Date and Time**
- **Checking Calendar**
- **Performing Calculation**
- **Displaying Messages**
- **Getting Help**
- **Command Line Shortcuts**
- **Changing Identity**
- **Root User**

---

## **Exercise 1: Getting Started**

- **Fedora** is an open-source Linux distribution sponsored by Red Hat.
- Focuses on the latest open-source technology.
- Has a **6-month release cycle**.
- **Download Fedora** from: [http://www.fedoraproject.org](http://www.fedoraproject.org/).
- **Starting Fedora in VMware:**
    1. Open **VMware Workstation**.
    2. Load the **Fedora Linux virtual image**.
    3. Login using:
        - **Username:** student
        - **Password:** password

---

## **Exercise 2: Linux Shell**

- The **Linux shell** is a command-line interface (**CLI**) that executes commands and returns output.
- Shells allow users to interact with the system through commands.
- **Common UNIX/Linux shells:** Bash, Zsh, Csh, Ksh, etc.
- **Checking the current shell:**
    - Run: `echo $SHELL`
    - Run: `echo $BASH_VERSION` (to check Bash version).

---

## **Exercise 3: Changing Your Password**

- Use the **passwd** command to change the current password.
- Example:
    
    ```bash
    passwd
    ```
    
- **Commands are case-sensitive.**
- Try changing passwords:
    - **abcdefg**
    - **easy**
    - **easyysae**
- **Clear terminal:** Run `clear`.

---

## **Exercise 4: Knowing Who is Logged In**

- **Check current login user:**
    
    ```bash
    whoami
    ```
    
- **Alternative method:**
    - The **login username** appears in the **default terminal prompt**.

---

## **Exercise 5: Current Date and Time**

- **Display system date and time:**
    
    ```bash
    date
    ```
    
- **Format date output:**
    
    ```bash
    date "+%Y-%m-%d %H:%M:%S"
    ```
    
- **Important:** If a format string contains spaces, enclose it in **single or double quotes**.

---

## **Exercise 6: Checking Calendar**

- **Display the current month's calendar:**
    
    ```bash
    cal
    ```
    
- **Display a specific month and year:**
    
    ```bash
    cal 12 2024
    ```
    
- **Display previous, current, and next month's calendar:**
    
    ```bash
    cal -3
    ```
    
- **Display calendars for January, February, and March of a specific year:**
    
    ```bash
    
    cal -3 2 2012
    
    ```
    

---

## **Exercise 7: Performing Calculation**

- **Use the `bc` command for arithmetic calculations:**
    
    ```bash
    echo "5+3" | bc
    ```
    

---

## **Exercise 8: Displaying Messages**

- **Display a string using `echo`:**
    
    ```bash
    echo "Hello, World!"
    ```
    
- **Embed commands within a string using `$()` or backquotes:**
    
    ```bash
    echo "Current user: $(whoami)"
    ```
    
- **Display "$(whoami)" as a string:**
    
    ```bash
    echo '$(whoami)'
    echo \$\(whoami\)
    ```
    

---

## **Exercise 9: Getting Help**

- **Get command manual pages:**
    
    ```bash
    man date
    ```
    
- **Understanding `man` page syntax:**
    - **`[]`** → Optional arguments (e.g., `[+FORMAT]`)
    - **`...`** → List of parameters (e.g., `[file ...]`)
    - **`|`** → OR options (e.g., `[-u|--utc|--universal]`)
    - **``** → Any combination of options (e.g., `[ -hlwsqv ]`)

### **Questions & Answers**

- **Is `+FORMAT` optional in `date`?** → **Yes**
- **Is the `+` sign required in `date +FORMAT`?** → **Yes**
- **Does `date -u`, `date --utc`, and `date --universal` give the same output?** → **Yes**
- **Check command descriptions:**
    
    ```bash
    whatis date
    ```
    
    - Note: The `whatis` command relies on a database, which updates **nightly**.

---

## **Exercise 10: Command Line Shortcuts**

- **View command history:**
    
    ```bash
    history
    ```
    
- **Keyboard shortcuts:**
    - **Up/Down arrow keys** → Navigate command history.
    - **`!n`** → Run command by history number.
    - **`!!`** → Repeat the last command.

---

## **Exercise 11: Changing Identity**

- **Switch user with `su`:**
    
    ```bash
    su username
    ```
    
- **Exit user session:**
    
    ```bash
    exit
    ```
    

---

## **Exercise 12: Root User**

- **The root user (superuser) has full system control.**
- **Switch to root user:**
    
    ```bash
    su -
    ```
    
- **Exit root session:**
    
    ```bash
    exit
    ```
    

---

### **End of Practical 6 Notes** 🚀
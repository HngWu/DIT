# Topic 6

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: January 20, 2025 1:25 PM

# Operating Systems and Administration - Process Management

## Learning Objectives

- Understand processes, threads and associated data structures
- Understand single and multithreading
- Understand and explain context switching
- Understand process states and process transition diagram

Scheduling consists of:

- **Managing CPU sharing** among ready processes and threads
- Requires **context switching** capability to function
- Scheduler responsibilities:
    - Selecting ready threads when CPU is available
    - Following scheduling policy to determine thread removal and allocation
- Scheduling mechanism controls:
    - When to interrupt the CPU
    - How threads are allocated and removed from CPU
    - Consists of:
        - enqueuer
        - dispatcher
        - context switcher
    - Process state transitions controlled by scheduler:
        - Enqueuer: Adds the ready process into queue which holds all processes which are ready to be executed by the CPU or ready list
        - Dispatcher: removes the next process in the ready list and sends it to the context switcher to allocate the CPU to that process
        - Context Switcher: responsible for saving the state of the old process and loading the state of the new process into the CPU’s register in order to have the CPU  execute the new process

## Scheduling Performance and Evaluation

Scheduling performance has significant impact on multiprogrammed computer systems:

- Process execution time depends on CPU allocation frequency by scheduler
- Main goals are to:
    - Decrease average process execution time
    - Increase system throughput (processes completed per unit time)

Key scheduling metrics:

- Wait Time (W(pi)) - Total time process spends waiting in ready list
- Turnaround Time (TTRnd(pi)) - Time from process entering ready state to last exit

## Types of Schedulers

### Nonpreemptive (Voluntary) Schedulers

- First-Come-First-Served (FCFS)
    - Selects first job that arrives in ready list
    - Simple but can cause convoy effect
- Shortest Job First (SJF)
    - Selects job with shortest execution time
    - Optimal for minimizing average wait time
- Priority (PR) (Nonpreemptive)
    - Selects job with highest priority
    - Can lead to starvation of low-priority processes

### Preemptive (Involuntary) Schedulers

- Preemptive SJF
    - Also known as Shortest-Remaining-Time-First (SRTF)
- Priority (PR)
    - Uses aging to prevent starvation
- Round Robin (RR)
    - Gives each process a time slice
    - Good for time-sharing systems
    - Performance depends on quantum size
- Multi-level Queues
    - Separate queues for different process types
    - Each queue can use different scheduling algorithms

## CPU Scheduling Examples and Calculations

A detailed look at how different scheduling algorithms work in practice:

### First-Come-First-Served (FCFS)

Key characteristics:

- Non-preemptive scheduling - processes run to completion
- Uses FCFS queue with new processes added to tail
- Process at queue head gets CPU when available
- Simple implementation but suffers from convoy effect

### Shortest-Job-First (SJF)

Implementation approaches:

- Non-preemptive: Process runs to completion once started
- Preemptive (SRTF): Can be interrupted by shorter processes
- Optimal for minimizing average wait time
- Requires knowing/estimating process execution times

### Priority Scheduling

Important considerations:

- Associates priority numbers with processes
- Can be preemptive or non-preemptive
- Uses aging to prevent starvation of low-priority processes
- Equal priority processes handled FCFS

### Round Robin (RR)

Implementation details:

- Uses time quantum (typically 10-100ms)
- Processes preempted after quantum expires
- Preempted processes go to queue end
- Performance depends on quantum size:
    - Large quantum approaches FCFS behavior
    - Small quantum increases context switching overhead

### Multilevel Queue

Structure and organization:

- Separates processes into different queues by type
- Each queue can use different scheduling algorithm
- Common setup:
    - Foreground (interactive) processes use RR
    - Background (batch) processes use FCFS

## Performance Analysis

Key metrics for evaluating scheduler performance:

- Gantt charts show process execution timeline
- Waiting time = time spent in ready queue
- Turnaround time = completion time - arrival time
- Average times calculated across all processes

## Operating System-Specific Scheduling Examples

### BSD 4.4 (Unix) Scheduling

- Uses involuntary CPU sharing
- Implements preemptive algorithms
- Features 32 multi-level queues:
    - Queues 0-7 reserved for system functions
    - Queues 8-31 dedicated to user space functions
    - 'nice' value influences but doesn't directly control queue level

### Windows Scheduling

- Implements involuntary CPU sharing across threads
- Uses preemptive algorithms
- Employs 32 multi-level queues:
    - Top 16 levels designated as "real-time"
    - Next 15 levels used for system/user threads
    - Lowest level reserved for idle thread
- Queue selection influenced by process base priority

### General Scheduling Conclusions

- Modern operating systems require scheduling for effective multi-programming
- Choice of scheduling policy significantly impacts system performance
- Hybrid scheduling approaches preferred as no single algorithm suits all scenarios
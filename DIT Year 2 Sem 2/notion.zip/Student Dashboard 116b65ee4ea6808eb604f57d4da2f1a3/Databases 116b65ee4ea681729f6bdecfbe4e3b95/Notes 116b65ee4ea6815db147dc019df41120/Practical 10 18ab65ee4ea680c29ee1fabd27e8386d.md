# Practical 10

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: January 30, 2025 2:38 AM

# **IT2164/IT2561: Operating Systems and Administration**

## **Practical 10: Linux File System – Security and File Ownership**

### **Objectives**

- **Understanding `/etc/passwd` and `/etc/shadow`**
- **Locking and Unlocking Passwords**
- **Creating User Groups (`groupadd`)**
- **Configuring `sudo` (`/etc/sudoers`)**
- **Sharing Files and Directories with Group Ownership (`id`, `usermod`)**

---

## **Exercise 1: Understanding `/etc/passwd`**

- **The `/etc/passwd` file** contains user account records, with fields separated by colons (`:`).

| **Field Name** | **Description** |
| --- | --- |
| **User Name** | Login username. |
| **User Password** | Stores a hashed password or `"x"` (password stored in `/etc/shadow`). |
| **User ID (UID)** | Unique number identifying the user. |
| **Group ID (GID)** | Identifies the user’s primary group. |
| **Gecos Field** | Contains user information (e.g., full name). |
| **Home Directory** | Specifies the user’s home directory. |
| **Shell Program** | Defines the shell that runs when the user logs in. |
- **The `/etc/shadow` file** stores hashed passwords and account control details.

| **Field Name** | **Description** |
| --- | --- |
| **User Name** | Login username. |
| **Password** | Salted and hashed password (or status exception). |
| **Last Change** | Days since **January 1, 1970**, when the password was last changed. |
| **Minimum** | Minimum days required between password changes. |
| **Maximum** | Maximum days before a password change is required. |
| **Warning** | Days before password expiration warning. |
| **Inactive** | Days before the account becomes inactive. |
| **Expire** | Account expiration date (in days since **January 1, 1970**). |

### **Managing Users and Groups**

- **View group information:**
    
    ```bash
    bash
    CopyEdit
    cat /etc/group
    
    ```
    
- **Create a new user (`guest`):**
    
    ```bash
    bash
    CopyEdit
    sudo useradd guest
    
    ```
    
- **A `"!!"` in the password field** indicates that the user login is disabled.

---

## **Exercise 2: Configuring `sudo` Command**

- **The `sudo` command** allows a permitted user to execute commands as **root** or another user.
- **Configuration file:** `/etc/sudoers` (edited using `visudo`).
- **Editing `sudoers`:**
    
    ```bash
    bash
    CopyEdit
    sudo visudo
    
    ```
    
    - Press **`i`** to enter **insert mode** in `vi`.
    - Add the following line under **User Aliases**:
        
        ```bash
        bash
        CopyEdit
        User_Alias IT2524_STUDENT = student
        
        ```
        
    - Add the following line under **Command Aliases**:
        
        ```bash
        bash
        CopyEdit
        Cmnd_Alias IT2524_COMMAND = /usr/sbin/visudo
        
        ```
        
    - Ensure the line allowing `"people in group wheel"` is commented out.
    - Save and exit (`ESC`, then `:wq`).

### **Testing `sudo` Access**

- **Logout from root** and test the `sudo` command as "student":
    
    ```bash
    bash
    CopyEdit
    sudo visudo
    
    ```
    
    - If the command fails, check if the correct **Command Alias** is used:
        
        ```bash
        bash
        CopyEdit
        Cmnd_Alias IT2524_COMMAND = /usr/sbin/visudo
        
        ```
        

---

## **Exercise 3: Sharing Files and Directories with Group Ownership**

### **Step 1: Setting Up Group Access**

- **Objective:** Share `~/project` between `student` and users in the `student` group.
- **Login as `guest`** and try to access `~student`'s home directory:
    
    ```bash
    bash
    CopyEdit
    cd ~student
    
    ```
    
    - **Access should be denied** due to default permissions.
- **Login as `student`** and configure group access:
    
    ```bash
    bash
    CopyEdit
    chmod 770 ~student
    mkdir ~/project
    chmod 770 ~/project
    
    ```
    
- **Create a shared file:**
    
    ```bash
    bash
    CopyEdit
    cd ~/project
    touch document1.txt
    
    ```
    

### **Step 2: Adding a New User (`may`)**

- **Login as `root`** and create a new user `may`:
    
    ```bash
    bash
    CopyEdit
    useradd may
    
    ```
    
- **Verify if `may` can access `~student`'s directory:**
    
    ```bash
    bash
    CopyEdit
    su - may
    cd ~student
    
    ```
    
    - **Access should be denied.**

### **Step 3: Adding `may` to the `student` Group**

- **Login as `root`** and add `may` to the `student` group:
    
    ```bash
    bash
    CopyEdit
    usermod -aG student may
    
    ```
    
- **Verify `may`'s group membership:**
    
    ```bash
    bash
    CopyEdit
    groups may
    
    ```
    

### **Step 4: Accessing Shared Directory as `may`**

- **Login as `may`** and check access:
    
    ```bash
    bash
    CopyEdit
    cd ~student/project
    
    ```
    
    - **Access should now be granted.**
- **Create a file as `may`:**
    
    ```bash
    bash
    CopyEdit
    touch document2.txt
    
    ```
    

### **Step 5: Group Ownership Issues**

- **Check group ownership of files:**
    
    ```bash
    bash
    CopyEdit
    ls -l ~student/project
    
    ```
    
    - Files created by `may` **do not inherit** the `student` group.

### **Step 6: Enforcing Group Ownership with SGID**

- **Login as `student`** and set the **SGID (Set Group ID) bit** on `~/project`:
    
    ```bash
    bash
    CopyEdit
    chmod g+s ~/project
    
    ```
    
- **Now, all new files created in `~/project` will inherit the directory’s group (`student`).**

### **Step 7: Testing SGID Configuration**

- **Login as `may`** and create another file:
    
    ```bash
    bash
    CopyEdit
    touch ~/student/project/document3.txt
    
    ```
    
- **Check file ownership:**
    
    ```bash
    bash
    CopyEdit
    ls -l ~/student/project
    
    ```
    
    - **Expected result:**
        - `document2.txt` has `may`’s group.
        - `document3.txt` inherits the `student` group due to the **SGID** setting.

---

## **Final Verification Steps**

- **Login as `student`** and verify file permissions:
    
    ```bash
    bash
    CopyEdit
    ls -l ~/project
    
    ```
    
    - Confirm that all files have the correct **group ownership** (`student`).

---

## **Key Takeaways**

- **User and Password Management**
    - `/etc/passwd` stores **user account details**.
    - `/etc/shadow` stores **hashed passwords and password policies**.
- **Managing `sudo` Permissions**
    - Use `visudo` to **safely edit** `/etc/sudoers`.
    - Define **User Aliases** and **Command Aliases** to restrict access.
- **Group-Based File Sharing**
    - Use **group ownership (`chown`)** and **permissions (`chmod`)** to control access.
    - Use **SGID (`chmod g+s`)** to ensure new files inherit the directory’s group.

---

### **End of Practical 10 Notes** 🚀
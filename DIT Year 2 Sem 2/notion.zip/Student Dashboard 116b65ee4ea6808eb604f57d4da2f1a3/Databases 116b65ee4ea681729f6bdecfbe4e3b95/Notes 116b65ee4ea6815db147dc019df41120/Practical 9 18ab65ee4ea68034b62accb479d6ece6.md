# Practical 9

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: February 10, 2025 1:15 PM

# **IT2164/IT2561: Operating Systems and Administration**

## **Practical 9: Linux Administration – Analyzing Processes**

### **Pre-Requisites & Objectives**

- **Processes**
- **Jobs**
- **Starting Background Jobs**
- **Signals**

---

## **Exercise 1: Processes**

- **Definition:**
    - A **process** is an instance of a running program.
- **View real-time process information:**
    
    ```bash
    top
    
    ps
    ```
    
    - **Key Fields in `top` Output:**

| **Field** | **Description** |
| --- | --- |
| **PID** | Unique process ID |
| **PR** | Process priority |
| **SHR** | Shared memory used |
| **VIRT** | Virtual memory used |
| **USER** | Process owner |
| **%CPU** | CPU usage |
| **TIME+** | Total CPU time used (in hundredths of a second) |
| **NI** | Nice value (-ve = higher priority, +ve = lower priority) |
| **%MEM** | Memory usage |

### **Process Management Commands**

- **Open two terminals:**
    1. In **Terminal 1**, start `vi`:
        
        ```bash
        vi
        ```
        
    2. In **Terminal 2**, list running processes:
        
        ```bash
        ps aux
        ```
        
- **Identify the process ID (PID) of `bash`:**
    
    ```bash
    ps -fe | grep bash
    ```
    
- **Switch to the root user and manage HTTP server processes:**
    
    ```bash
    su -
    systemctl start httpd
    ps aux | grep httpd
    ```
    
- **Terminate child processes of `httpd`:**
    
    ```bash
    kill <PID>
    ```
    

---

## **Exercise 2: Jobs**

- **Definition:**
    - A **job** is a background process initiated from the shell.
- **List all jobs:**
    
    ```bash
    jobs
    ```
    
- **Run `vi` and enter some text:**
    1. Open `vi`:
        
        ```bash
        v
        ```
        
    2. Press **Esc**, then **CTRL+Z** to suspend `vi` and return to the shell.
- **Check if `vi` is still running:**
    
    ```bash
    ps
    jo
    ```
    
- **Bring `vi` back to the foreground:**(Replace `%1` with the job number from the `jobs` command.)
    
    ```bash
    fg %1
    ```
    
- **Exit `vi`, then list active jobs:**
    
    ```bash
    jobs
    ```
    

---

## **Exercise 3: Starting Background Jobs**

- **Create a script (`loop.sh`):**
    
    ```bash
    nano loop.sh
    ```
    
    - Add the following content:
        
        ```bash
        #!/bin/bash
        while true; do
          echo "Running..."
          sleep 5
        done
        ```
        
    - Save the file (`CTRL+X`, then `Y`, then `Enter`).
- **Give execution permissions:**
    
    ```bash
    chmod +x loop.sh
    ```
    
- **Run script in the background:**
    
    ```bash
    ./loop.sh &
    ```
    
- **Suspend the job:**
    - Press **CTRL+Z** to stop it.
- **Restart the job in the background:**
    
    ```bash
    bg %
    ```
    

---

## **Exercise 4: Signals**

- **Definition:**
    - Signals are software interrupts used to notify processes of specific events.
- **List available signals:**
    
    ```bash
    kill -l
    ```
    
- **Types of default signal actions:**

| **Action** | **Description** |
| --- | --- |
| **Exit** | Terminates the process |
| **Core** | Terminates and creates a core dump |
| **Stop** | Suspends the process |
| **Ignore** | No action taken |

### **Using `kill` to Terminate Processes**

- **Terminate a process (default signal 15 - `SIGTERM`):**
    
    ```bash
    kill <PID>
    ```
    
- **Forcefully terminate a process (signal 9 - `SIGKILL`):**
    
    ```bash
    kill -9 <PID>
    ```
    
    - **Note:**
        - `SIGTERM` (15) allows the process to clean up before exiting.
        - `SIGKILL` (9) immediately stops the process without cleanup.

---

### **End of Practical 9 Notes** 🚀
# Practical 6 & 7( Test 2)

Course: Operating Systems And Management (../Courses%20116b65ee4ea6813db5b5d6925de4320b/Operating%20Systems%20And%20Management%20116b65ee4ea680c29c79e64fcd829ada.md)
Confidence: Not Confident
Last Edited: January 20, 2025 1:01 PM

- **Basic Commands**
1. echo $SHELL - Displays the current shell program.
2. echo $BASH_VERSION - Displays the version of the bash shell.
3. passwd - Changes the current password.
4. clear - Clears the terminal screen.

---

- **User Information**
1. whoami - Displays the current login user.
2. who - Displays information about all logged-in users.

---

- **Date and Time**
1. date - Displays the current system date and time.
2. date '+FORMAT' - Formats the date and time output.

---

- **Calendar**
1. cal - Displays the calendar for the current month.
2. cal YYYY-MM - Displays the calendar for a specific month and year.
3. cal -3 - Displays the previous, current, and next month's calendars.

---

- **Arithmetic Calculations**
1. bc - Opens the basic calculator for arithmetic calculations.

---

- **Displaying Messages**
1. echo 'text' - Displays a string of text.
2. echo "$COMMAND" - Displays a string containing a command without executing it.

---

- **Help and Manual**
1. man COMMAND - Displays the manual for the specified command.
2. whatis COMMAND - Displays a short description of the specified command.

---

- **Command Line Shortcuts**
1. history - Displays the history of executed commands.
2. !! - Repeats the last executed command.
3. !n - Executes a specific command from history by its number.

---

- **Identity and User Switching**
1. su USERNAME - Switches to another user account.
2. su - - Switches to the root user.

### **Standard Directories**

1. ls -l / - Display contents of the root directory.
2. ls /bin - Display contents of the /bin directory.

---

### **Listing Directory Contents**

1. pwd - Display the current directory.
2. ls - List contents of the current directory.
3. ls -l - List contents in long format.
4. ls -l chart* - Display files starting with "chart".
5. ls -l report* - Display files starting with "report".
6. ls -l chart* report* - Display files starting with "chart" and "report".

---

### **Navigating Directories**

1. cd /etc - Change to the /etc directory.
2. cd ~/tmp - Change to the tmp directory in the user's home directory.
3. cd ../backup - Move to the parent directory and then into the backup directory.
4. cd Desktop - Change to the Desktop directory.
5. cd ~ - Go to the home directory.
6. cd / - Go to the root directory.
7. cd - - Switch to the previous working directory.

---

### **Hidden Files**

1. ls .* - List all hidden files.

---

### **Creating and Switching Directories**

1. mkdir <directory_name> - Create a directory.
2. ls -l - Confirm the creation of directories (look for d in the file type field).

---

### **Copying Files**

1. cp <source> <destination> - Copy files to a directory.
2. ls -Rl - List files recursively, including files in subdirectories.

---

### **Moving Files**

1. mv <source> <destination> - Move files to a directory.
2. mv <old_name> <new_name> - Rename a file.

---

### **Removing Files and Directories**

1. rm <file_name> - Remove a file.
2. rmdir <directory_name> - Remove an empty directory.
3. rm -R <directory_name> - Remove a directory and its contents recursively.

---

### **File Permissions**

1. ls -l - Display file permissions.
2. chmod <permissions> <file> - Change file permissions using numeric representation.
    - Example: chmod 755 file.txt
3. chmod u+x <file> - Add execute permission for the user.
4. chmod g-w <file> - Remove write permission for the group.
5. chmod o=r <file> - Set read permission only for others.

---

### **Links**

1. echo "apple" > apple.txt - Create a file named apple.txt with content "apple".
2. ln apple.txt orange.txt - Create a hard link orange.txt to apple.txt.
3. ln -s apple.txt pear.txt - Create a symbolic link pear.txt to apple.txt.
4. cat <file> - Display the content of a file.
5. ls -l *.txt - List all .txt files.

---